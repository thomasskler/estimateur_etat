OpenDSS users:

The idea of this software is to simulate n scenarios for each penetration level given by the user. 
The key is to evaluate if there is any sigle-phase transformer with overload, any first three-phase parent bus of the transformer with 
unbalanced voltage and, finally, any load with voltage level violation.

Basically, 
	There are n scenarios for each penetration level
	There are two conditions for each scenario: 
		1- PVsystems with PF=1
		2- PVsystems with PF=-0.985
	There are a number of simulations for each condition (in the original case is 24, because the daily mode with number=24 is been performed).

That been said, for each time step of the simulation, the python code through COM interface ask if there is any of the issues described.

As a result files, you can find:

1 - Output files for each penetration level: ...\ckt5\Results\penetrationlevel
	In each of those files, you going to find either summaryResults_pf1.csv and summaryResults_pf985.csv.  
2 - ConsumersIssue.png
	This figure shows the consumers with voltage issue for each penetration level. 
	The number of consumers is the average of the consumers that has voltage violation considering just the scenarios with voltage issue
3 - ScenariosIssue.png
	This figure shows the scenarios with voltage issue for each penetration level.


This software is made by using three .py files. Each .py file has one class.

File 1: MasterSettings.py
	This file presents to the users few options which can control the simulation. The class defined in this file is
	called as Settings. YOU SHOULD RUN THIS SCRIPT
File 2: ControlOpenDSS.py
	The class in this file creates an OpenDSS object each time that it is called by the Settings class.
File 3: PlotResults.py
	The PlotResults class plots two different figures.


In order to run this software, you need to use the CKT5 EPRITestCircuits. 
Find it at: https://sourceforge.net/p/electricdss/code/HEAD/tree/trunk/Distrib/EPRITestCircuits/ckt5/

Moreover, you need to include into this folder the following porvided files:

File 1: buses.csv
	This file has all buses of the loads. 
File 2: offPeakload.csv
	This file presents the offpeak loadshape
File 3: Peakload.csv
	This file presents the peak loadshape
File 4: PVGenCurve_1.txt
	This file presents the curves for the PVSystems for the sunny day
File 5: PVGenCurve_2.txt
	This file presents the curves for the PVSystems for the cloudy day

Original Author: Paulo Radatz. E-mail for any question: paulo.radatz@gmail.com